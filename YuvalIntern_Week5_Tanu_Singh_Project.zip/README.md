# YuvalIntern Week 5 — Deep Learning Application in Data Science

**Trainee:** Tanu Singh  
**Role:** Virtual Data Science with Python Trainee

## Objective
Build a neural-network model using Python and a public dataset.

## Dataset
The public handwritten digits dataset distributed by Scikit-learn. It contains 8×8 grayscale digit images for ten classes (0–9).

## Deep Learning Framework
PyTorch was used to implement a multilayer perceptron (MLP).

### Architecture
- Input: 64 pixel features
- Dense layer: 128 neurons + ReLU
- Dropout: 20%
- Dense layer: 64 neurons + ReLU
- Dropout: 20%
- Output: 10 neurons
- Loss: Cross-Entropy
- Optimizer: Adam
- Learning rate: 0.001
- Weight decay: 0.0001
- Epochs: 30
- Batch size: 64

## Result
Test accuracy: **0.975 (97.50%)**

## Structure
- `data/` — dataset and training outputs
- `figures/` — training and evaluation charts
- `src/` — reproducible PyTorch code
- `reports/` — final Word report
- `digits_mlp_model.pt` — trained model weights
